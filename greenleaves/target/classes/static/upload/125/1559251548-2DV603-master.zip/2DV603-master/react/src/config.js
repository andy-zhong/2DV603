let config = {
    requestUrl: "http://localhost:8080/",
};

export default config;
