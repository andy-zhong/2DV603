package com.greenleaves.application;


public class IndexApplication {

    public String index() {
        return "Hello World!";
    }

}
